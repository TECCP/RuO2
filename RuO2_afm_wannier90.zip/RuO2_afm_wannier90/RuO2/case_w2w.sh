#!/bin/bash
#PBS -q luna
#PBS -l select=1:ncpus=1:mem=40gb:scratch_local=100gb:host=luna105.fzu.cz
#PBS -l walltime=24:00:00

DATADIR=$PBS_O_WORKDIR
CASEDIR=$(basename $PBS_O_WORKDIR)
export PATH=/usr/local/bin:/usr/bin:/bin:/software/meta-utils/public; export LD_LIBRARY_PATH=
module add intelcdk-19u3
module add ofed-1.5.4
module add openmpi-3.1.2-intel
export LD_LIBRARY_PATH=/storage/praha1/home/asurada/program/fftw/3.3.9/intel-19.0.3/double/lib:$LD_LIBRARY_PATH
export PATH=$PATH:/storage/praha1/home/asurada/program/wannier90/2.0.1/intel-19.0.3
# added by WIEN2k: BEGIN
# --------------------------------------------------------
alias lsi="ls -aslp *.in*"
alias lso="ls -aslp *.output*"
alias lsd="ls -aslp *.def"
alias lsc="ls -aslp *.clm*"
alias lss="ls -aslp *.scf* */*.scf"
alias lse="ls -aslp *.error"
alias LS="ls -aslp | grep /"
alias pslapw="ps -ef |grep "lapw""
alias cdw="cd /storage/praha1/home/asurada/nwork"
export OMP_NUM_THREADS=1
#export LD_LIBRARY_PATH=.....
export EDITOR="xterm -e vi"
export SCRATCH=./
export WIENROOT=/auto/praha1/asurada/program/wien2k/intel-19.0.3/WIEN2k_17.1
export W2WEB_CASE_BASEDIR=/storage/praha1/home/asurada/nwork
export STRUCTEDIT_PATH=$WIENROOT/SRC_structeditor/bin
export PDFREADER=xpdf
export PATH=$WIENROOT:$STRUCTEDIT_PATH:$WIENROOT/SRC_IRelast/script-elastic:$PATH:.
export OCTAVE_EXEC_PATH=${PATH}::
export OCTAVE_PATH=${STRUCTEDIT_PATH}::
export PATH=$PATH:$WIENROOT:.
ulimit -s unlimited
alias octave="octave -p $OCTAVE_PATH"
# --------------------------------------------------------
# added by WIEN2k: END 
# --- BERRYPI START ---
export BERRYPI_PATH=$WIENROOT/SRC_BerryPI/BerryPI
export BERRYPI_PYTHON=/usr/bin/python2.7
alias berrypi="${BERRYPI_PYTHON} ${BERRYPI_PATH}/berrypi"
# --- BERRYPI END ---

echo "$PBS_JOBID is running on node `hostname -f` in a scratch directory $SCRATCHDIR" >> $DATADIR/jobs_info.txt
test -n "$SCRATCHDIR" || { echo >&2 "Variable SCRATCHDIR is not set!"; exit 1; }
mkdir $SCRATCHDIR/$CASEDIR
echo "\cp -r $DATADIR/* $SCRATCHDIR/$CASEDIR"; \cp -r $DATADIR/* $SCRATCHDIR/$CASEDIR || { echo >&2 "Error while copying input file(s)!"; exit 2; }
echo "cd $SCRATCHDIR/$CASEDIR"; cd $SCRATCHDIR/$CASEDIR
awk '{ print("1:" $0 ); }' $PBS_NODEFILE > .machines
echo 'granularity:1' >> '.machines'
echo
echo PATH=$PATH
echo
echo
echo Running job
echo
echo Begin; date
#
############################################
### PART 1. WIEN2K                       ###
############################################
### x kgen -fbz                          ###
### CHECK: no shift                      ###
############################################
\cp RuO2.struct_orig RuO2.struct
x lapw1 -up -orb
x lapw1 -dn -orb
\cp RuO2.struct_rot  RuO2.struct
#
############################################
### PART 2. WIEN2WANNIER & WANNIER90     ###
############################################
### write_inwf -up                       ###
### write_inwf -dn                       ###
### write_win -up                        ###
### CHECK: case.fermiup and case.fermidn ###
############################################
x wannier90 -pp
x w2w -up
x w2w -dn
x wannier90 -up
x wannier90 -dn
rm *.vector* -rf
#
echo End; date
echo
echo "\cp -r $SCRATCHDIR/$CASEDIR/* $DATADIR"; \cp -r $SCRATCHDIR/$CASEDIR/* $DATADIR || { echo >&2 "Result file(s) copying failed (with a code $?) !!"; exit 4; }
clean_scratch

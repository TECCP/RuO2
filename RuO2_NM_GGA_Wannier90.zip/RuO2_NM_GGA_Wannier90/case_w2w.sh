#$ -cwd
#$ -j y
#$ -S /bin/bash
#$ -V
# -q all.q
# -pe mpi_5 5

DIR_NAME=$(basename $(pwd))
DIR_HOME=$(pwd)
SRC_DIR=/work/$USER/$JOB_ID
if [ ! -d $SRC_DIR ]; then
mkdir -p $SRC_DIR
fi
cp -r $DIR_HOME $SRC_DIR
cd $SRC_DIR/$DIR_NAME
echo PATH=$PATH
echo HOME=$DIR_HOME
echo WORK=$SRC_DIR/$DIR_NAME
echo
echo
echo Running job
echo
echo Begin; date
#
############################################
### PART 1. WIEN2K                       ###
############################################
### x kgen -fbz                          ###
### CHECK: no shift                      ###
############################################
x lapw1
#
############################################
### PART 2. WIEN2WANNIER & WANNIER90     ###
############################################
### write_inwf                           ###
### write_win                            ###
### CHECK: case.fermi                    ###
############################################
x wannier90 -pp
x w2w
x wannier90
#
echo End; date
echo
echo "> rm -rf $SRC_DIR/$DIR_NAME/$JOB_NAME.o$JOB_ID $SRC_DIR/$DIR_NAME/$JOB_NAME.po$JOB_ID"
rm -rf $SRC_DIR/$DIR_NAME/$JOB_NAME.o$JOB_ID $SRC_DIR/$DIR_NAME/$JOB_NAME.po$JOB_ID
echo "> \cp -r $SRC_DIR/$DIR_NAME/* $DIR_HOME"; \cp -r $SRC_DIR/$DIR_NAME/* $DIR_HOME
echo "> rm -rf $SRC_DIR"; rm -rf $SRC_DIR

#$ -cwd
#$ -j y
#$ -S /bin/bash
#$ -V
#$ -q all.q
#$ -pe mpi_9 9

DIR_NAME=$(basename $(pwd))
DIR_HOME=$(pwd)
SRC_DIR=/work/$USER/$JOB_ID
if [ ! -d $SRC_DIR ]; then
mkdir -p $SRC_DIR
fi
cp -r $DIR_HOME $SRC_DIR
cd $SRC_DIR/$DIR_NAME
echo PATH=$PATH
echo HOME=$DIR_HOME
echo WORK=$SRC_DIR/$DIR_NAME
echo
echo
echo Running job
echo
echo Begin; date
#
run_lapw -p -ec 0.0000001 -cc 0.000001
#
echo End; date
echo
echo "> rm -rf $SRC_DIR/$DIR_NAME/$JOB_NAME.o$JOB_ID $SRC_DIR/$DIR_NAME/$JOB_NAME.po$JOB_ID"
rm -rf $SRC_DIR/$DIR_NAME/$JOB_NAME.o$JOB_ID $SRC_DIR/$DIR_NAME/$JOB_NAME.po$JOB_ID
echo "> \cp -r $SRC_DIR/$DIR_NAME/* $DIR_HOME"; \cp -r $SRC_DIR/$DIR_NAME/* $DIR_HOME
echo "> rm -rf $SRC_DIR"; rm -rf $SRC_DIR

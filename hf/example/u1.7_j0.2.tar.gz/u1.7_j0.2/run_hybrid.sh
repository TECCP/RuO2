#$ -cwd
#$ -j y
#$ -S /bin/bash
#$ -V
#$ -q all.q
#$ -pe mpi_4 4

# Modify here!
# N_SLOTS     : How many cores do you want to use? It should be equal to [-pe mpi_# #].
# N_ITER_FIRST: The index of the first step, usually 1.
# N_ITER_LAST : The index of the last step, i.e., how many iterations do you want?
N_SLOTS=4
N_ITER_FIRST=1
N_ITER_LAST=200

DIR_NAME=$(basename $(pwd))
DIR_HOME=$(pwd)
SRC_DIR=/work/$USER/$JOB_ID
if [ ! -d $SRC_DIR ]; then
mkdir -p $SRC_DIR
fi
cp -r $DIR_HOME $SRC_DIR
cd $SRC_DIR/$DIR_NAME
echo PATH=$PATH
echo HOME=$DIR_HOME
echo WORK=$SRC_DIR/$DIR_NAME
echo
echo
echo Running job
echo
echo Begin; date

# ==================================================

n=$N_ITER_FIRST
while [ $n -le $N_ITER_LAST ]
do
  echo
  echo "LOOP#$n START"
  echo "$n. ITERATION" | cat >> scf; echo  | cat >> scf
  echo
  echo " \mv n.dmft n.dmft_old"; \mv n.dmft n.dmft_old
# DMFT START
  echo
  echo " dmft"
  mpirun -np $N_SLOTS dmft
  echo " DMFT END"; date
  echo " cat dmft.out >> scf"; cat dmft.out >> scf; echo  | cat >> scf
# CHECK OCC
  echo
  echo " mx_occ"; mx_occ
  echo " \mv n.dmft_mix n.dmft"; \mv n.dmft_mix n.dmft
  echo " ck_mm"; ck_mm
# HF START
  echo
  echo " mk_kanamori_mf_h"; mk_kanamori_mf_h
  echo " HF END"; date
  echo " \mv hamilt_hmf hamilt"; \mv hamilt_hmf hamilt
  echo
  echo "LOOP#$n END"
  let n=n+1
done

echo "mkdir save_${N_ITER_FIRST}_${N_ITER_LAST}"; mkdir save_${N_ITER_FIRST}_${N_ITER_LAST}
echo "\mv scf save_${N_ITER_FIRST}_${N_ITER_LAST}"; \mv scf save_${N_ITER_FIRST}_${N_ITER_LAST}
echo "\cp n.dmft save_${N_ITER_FIRST}_${N_ITER_LAST}"; \cp n.dmft save_${N_ITER_FIRST}_${N_ITER_LAST}

echo
echo "Finishing HF loops"
echo

# ==================================================

echo End; date
echo
echo "> rm -rf $SRC_DIR/$DIR_NAME/$JOB_NAME.o$JOB_ID $SRC_DIR/$DIR_NAME/$JOB_NAME.po$JOB_ID"
rm -rf $SRC_DIR/$DIR_NAME/$JOB_NAME.o$JOB_ID $SRC_DIR/$DIR_NAME/$JOB_NAME.po$JOB_ID
echo "> \cp -r $SRC_DIR/$DIR_NAME/* $DIR_HOME"; \cp -r $SRC_DIR/$DIR_NAME/* $DIR_HOME
echo "> rm -rf $SRC_DIR"; rm -rf $SRC_DIR
